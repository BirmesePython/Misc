/*
===========================================
Author: Justin Muskopf
Program: func.c
Description: Defines the sayHello function
===========================================
*/

#include "prgm.h" //Include stdio.h for printf, and declares function sayHello


//Function definition
void sayHello()
{
	//Print status-quo cliche
	printf("Hello World!\n");

	return;
}
