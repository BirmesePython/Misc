/*
============================================
Author: Justin Muskopf
Program: main.c
Description: Consists only of main function
============================================
*/

#include "prgm.h" //Include stdio.h for printf, and declares function sayHello

int main()
{
	//Call the function that is prototyped in prgm.h and defined in func.c
	sayHello();

	return 0;
}
