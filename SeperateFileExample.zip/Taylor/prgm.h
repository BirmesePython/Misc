/*
====================================================================
Author: Justin Muskopf
Program: prgm.h
Description: Includes necessary libs & Declares function prototypes
====================================================================
*/

#include <stdio.h> //Printf & scanf

//Function prototype
void sayHello();
